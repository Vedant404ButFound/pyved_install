from setuptools import find_packages
from distutils.core import setup
setup(
    name='pyved',
    version='1.1',
    packages=find_packages(),
    install_requires=['pandas','pywhatkit','xlrd','openpyxl','plyer'],
    author='Vedant Goswami',
    url='https://github.com/Vedant404ButFound/pyved/',
    download_url='https://github.com/Vedant404ButFound/pyved_install/raw/master/pyved-1.1.tar.gz',
    author_email='vedant2904goswami@gmail.com',
    license='MIT',
)