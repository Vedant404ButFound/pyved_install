from setuptools import find_packages
from distutils.core import setup
def readme():
    with open('README.MD','r') as f:
        long_desc = f.read()
    return long_desc
setup(
    name='pyved',
    version='1.1',
    packages=find_packages(),
    install_requires=['pandas','pywhatkit','xlrd','openpyxl','plyer'],
    author='Vedant Goswami',
    url='https://github.com/Vedant404ButFound/pyved/',
    download_url='https://github.com/Vedant404ButFound/pyved_install/raw/master/pyved-1.1.tar.gz',
    long_description=readme(),
    long_description_content_type="text/markdown",
    author_email='vedant2904goswami@gmail.com',
    license='MIT',
)