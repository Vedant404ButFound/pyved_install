from setuptools import find_packages
from distutils.core import setup
def readme():
    with open('README.MD','r') as f:
        content = f.read()
    return content
setup(
    name='pyved',
    version='1.0',
    packages=find_packages(),
    install_requires=['pandas','pywhatkit','bs4','pyfiglet','xlrd','openpyxl','plyer'],
    author='Vedant Goswami',
    url='https://github.com/Vedant404ButFound/pyved_install/',
    download_url='https://github.com/Vedant404ButFound/pyved_install/master/pyved-1.0.tar.gz',
    long_description=readme(),
    

)